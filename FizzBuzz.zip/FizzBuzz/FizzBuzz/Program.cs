﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            //SimpleFizzBuzz();

            //Write a console application, using your SuperFizzBuzz class, to solve the classic FizzBuzz problem as described above in “The Basics”.

            new SuperFizzBuzz.SuperFizzBuzz(
                new Dictionary<string, int>
                {
                    { "Fizz", 3 }, { "Buzz", 5 }, { "Frog", 4 }
                },
                Enumerable.Range(1,100 ).ToList()
            );
            Console.ReadKey();
            //Write a second console application demonstrating advanced usage of SuperFizzBuzz that 
            new SuperFizzBuzz.SuperFizzBuzz(
                new Dictionary<string, int>
                {
                    { "Fizz", 3 }, { "Buzz", 7 }, { "Frog",38 }
                },
                Enumerable.Range(-12, 145).ToList()
            );

            Console.ReadKey();
        }

        static void SimpleFizzBuzz()
        {
            for (var x = 1; x <= 100; x++)
            {

                if ((x % 3 == 0) && (x % 5 == 0))
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if ((x % 3 == 0))
                {
                    Console.WriteLine("Fizz");
                }
                else if ((x % 5 == 0))
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(x.ToString());
                }
            }
            Console.ReadKey();
        }
    }
}

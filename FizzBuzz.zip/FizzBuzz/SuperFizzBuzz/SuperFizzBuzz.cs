﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SuperFizzBuzz
{
    public class SuperFizzBuzz
    {
        public SuperFizzBuzz(Dictionary<string, int> tokens, List<int> list)
        {
            var r = list.Select(x => tokens.Count(c => (x % c.Value) == 0) != 0 ? String.Join("", tokens.Where(c => (x % c.Value) == 0).Select(v => v.Key).ToArray()) : x.ToString()).ToList();
            r.ForEach(Console.WriteLine);
        }

    }
}